#include "models/note.h"

Note::Note()
    : m_id(QUuid::createUuid().toString(QUuid::WithoutBraces))
    , m_label(Label::None)
    , m_createdAt(QDateTime::currentDateTime())
    , m_updatedAt(QDateTime::currentDateTime())
{
}

Note::Note(const QString &title, const QString &body, Label label)
    : m_id(QUuid::createUuid().toString(QUuid::WithoutBraces))
    , m_title(title)
    , m_body(body)
    , m_label(label)
    , m_createdAt(QDateTime::currentDateTime())
    , m_updatedAt(QDateTime::currentDateTime())
{
}

QString Note::id() const { return m_id; }
QString Note::title() const { return m_title; }
QString Note::body() const { return m_body; }
Label Note::label() const { return m_label; }
QDateTime Note::createdAt() const { return m_createdAt; }
QDateTime Note::updatedAt() const { return m_updatedAt; }

void Note::setTitle(const QString &title) {
    m_title = title;
    touch();
}

void Note::setBody(const QString &body) {
    m_body = body;
    touch();
}

void Note::setLabel(Label label) {
    m_label = label;
    touch();
}

void Note::touch() {
    m_updatedAt = QDateTime::currentDateTime();
}

QJsonObject Note::toJson() const {
    QJsonObject json;
    json["id"] = m_id;
    json["title"] = m_title;
    json["body"] = m_body;
    json["label"] = LabelUtils::toString(m_label);
    json["createdAt"] = m_createdAt.toString(Qt::ISODate);
    json["updatedAt"] = m_updatedAt.toString(Qt::ISODate);
    return json;
}

Note Note::fromJson(const QJsonObject &json) {
    Note note;
    note.m_id = json["id"].toString();
    note.m_title = json["title"].toString();
    note.m_body = json["body"].toString();
    note.m_label = LabelUtils::fromString(json["label"].toString());
    note.m_createdAt = QDateTime::fromString(json["createdAt"].toString(), Qt::ISODate);
    note.m_updatedAt = QDateTime::fromString(json["updatedAt"].toString(), Qt::ISODate);
    return note;
}

bool Note::operator==(const Note &other) const {
    return m_id == other.m_id;
}

bool Note::operator!=(const Note &other) const {
    return !(*this == other);
}
