#ifndef NOTE_H
#define NOTE_H

#include <QString>
#include <QDateTime>
#include <QJsonObject>
#include <QUuid>

#include "models/label.h"

class Note {
public:
    Note();
    Note(const QString &title, const QString &body, Label label = Label::None);

    QString id() const;
    QString title() const;
    QString body() const;
    Label label() const;
    QDateTime createdAt() const;
    QDateTime updatedAt() const;

    void setTitle(const QString &title);
    void setBody(const QString &body);
    void setLabel(Label label);

    QJsonObject toJson() const;
    static Note fromJson(const QJsonObject &json);

    bool operator==(const Note &other) const;
    bool operator!=(const Note &other) const;

private:
    QString m_id;
    QString m_title;
    QString m_body;
    Label m_label;
    QDateTime m_createdAt;
    QDateTime m_updatedAt;

    void touch();
};

#endif // NOTE_H
