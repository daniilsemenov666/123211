#include "models/label.h"

QString LabelUtils::toString(Label label) {
    switch (label) {
    case Label::Work:     return QStringLiteral("Работа");
    case Label::Personal: return QStringLiteral("Личное");
    case Label::Study:    return QStringLiteral("Учёба");
    case Label::Urgent:   return QStringLiteral("Срочное");
    case Label::Ideas:    return QStringLiteral("Идеи");
    default:              return QStringLiteral("Без метки");
    }
}

Label LabelUtils::fromString(const QString &str) {
    if (str == QStringLiteral("Работа"))    return Label::Work;
    if (str == QStringLiteral("Личное"))    return Label::Personal;
    if (str == QStringLiteral("Учёба"))     return Label::Study;
    if (str == QStringLiteral("Срочное"))   return Label::Urgent;
    if (str == QStringLiteral("Идеи"))      return Label::Ideas;
    return Label::None;
}

QColor LabelUtils::toColor(Label label) {
    switch (label) {
    case Label::Work:     return QColor(66, 133, 244);   // синий
    case Label::Personal: return QColor(52, 168, 83);    // зелёный
    case Label::Study:    return QColor(251, 188, 4);    // жёлтый
    case Label::Urgent:   return QColor(234, 67, 53);    // красный
    case Label::Ideas:    return QColor(154, 110, 219);  // фиолетовый
    default:              return QColor(158, 158, 158);  // серый
    }
}

QVector<Label> LabelUtils::allLabels() {
    return {
        Label::None,
        Label::Work,
        Label::Personal,
        Label::Study,
        Label::Urgent,
        Label::Ideas
    };
}
