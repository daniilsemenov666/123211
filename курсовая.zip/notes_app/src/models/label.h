#ifndef LABEL_H
#define LABEL_H

#include <QString>
#include <QVector>
#include <QColor>

enum class Label {
    None = 0,
    Work,
    Personal,
    Study,
    Urgent,
    Ideas
};

class LabelUtils {
public:
    static QString toString(Label label);
    static Label fromString(const QString &str);
    static QColor toColor(Label label);
    static QVector<Label> allLabels();
};

#endif // LABEL_H
