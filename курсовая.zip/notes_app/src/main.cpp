#include <QApplication>

#include "services/storageservice.h"
#include "services/notemanager.h"
#include "ui/mainwindow.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("NotesApp"));
    app.setOrganizationName(QStringLiteral("CourseWork"));

    StorageService storage;
    NoteManager manager(&storage);
    manager.loadAll();

    MainWindow window(&manager);
    window.show();

    return app.exec();
}
