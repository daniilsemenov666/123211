#include "ui/mainwindow.h"
#include "ui/notecard.h"
#include "ui/notedialog.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QWidget>

MainWindow::MainWindow(NoteManager *manager, QWidget *parent)
    : QMainWindow(parent)
    , m_manager(manager)
{
    setupUi();
    setupToolbar();
    refreshNotesList();

    connect(m_manager, &NoteManager::notesChanged, this, &MainWindow::refreshNotesList);
}

void MainWindow::setupUi() {
    setWindowTitle(QStringLiteral("📝 Заметки"));
    setMinimumSize(700, 500);
    resize(800, 600);

    setStyleSheet("QMainWindow { background-color: #f5f5f5; }");

    m_centralWidget = new QWidget(this);
    auto *mainLayout = new QVBoxLayout(m_centralWidget);
    mainLayout->setContentsMargins(16, 16, 16, 16);

    // Область прокрутки для заметок
    m_scrollArea = new QScrollArea(this);
    m_scrollArea->setWidgetResizable(true);
    m_scrollArea->setStyleSheet("QScrollArea { border: none; background: transparent; }");

    auto *scrollContent = new QWidget();
    m_notesLayout = new QVBoxLayout(scrollContent);
    m_notesLayout->setSpacing(10);
    m_notesLayout->addStretch();

    m_scrollArea->setWidget(scrollContent);
    mainLayout->addWidget(m_scrollArea);

    setCentralWidget(m_centralWidget);
}

void MainWindow::setupToolbar() {
    auto *toolbar = new QWidget(this);
    auto *toolbarLayout = new QHBoxLayout(toolbar);
    toolbarLayout->setContentsMargins(0, 0, 0, 8);

    // Поиск
    m_searchEdit = new QLineEdit(this);
    m_searchEdit->setPlaceholderText(QStringLiteral("🔍 Поиск..."));
    m_searchEdit->setStyleSheet(
        "padding: 8px; font-size: 13px; border: 1px solid #ccc; border-radius: 4px;"
        );

    // Фильтр по лейблу
    m_filterCombo = new QComboBox(this);
    m_filterCombo->addItem(QStringLiteral("Все заметки"), -1);
    for (Label label : LabelUtils::allLabels()) {
        m_filterCombo->addItem(LabelUtils::toString(label), static_cast<int>(label));
    }
    m_filterCombo->setStyleSheet("padding: 6px; font-size: 13px;");

    // Сортировка
    m_sortCombo = new QComboBox(this);
    m_sortCombo->addItem(QStringLiteral("Сначала новые"), 0);
    m_sortCombo->addItem(QStringLiteral("Сначала старые"), 1);
    m_sortCombo->addItem(QStringLiteral("По названию"), 2);
    m_sortCombo->setStyleSheet("padding: 6px; font-size: 13px;");

    // Кнопка добавления
    m_addButton = new QPushButton(QStringLiteral("➕ Новая заметка"), this);
    m_addButton->setStyleSheet(
        "QPushButton { background-color: #34a853; color: white; border: none;"
        "border-radius: 6px; padding: 10px 20px; font-size: 14px; font-weight: bold; }"
        "QPushButton:hover { background-color: #2d8e47; }"
        );

    toolbarLayout->addWidget(m_searchEdit, 2);
    toolbarLayout->addWidget(m_filterCombo);
    toolbarLayout->addWidget(m_sortCombo);
    toolbarLayout->addWidget(m_addButton);

    // Вставляем тулбар перед скролл-областью
    auto *centralLayout = qobject_cast<QVBoxLayout*>(m_centralWidget->layout());
    centralLayout->insertWidget(0, toolbar);

    connect(m_addButton, &QPushButton::clicked, this, &MainWindow::onAddNote);
    connect(m_filterCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onFilterChanged);
    connect(m_sortCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onFilterChanged);
    connect(m_searchEdit, &QLineEdit::textChanged, this, &MainWindow::onFilterChanged);
}

void MainWindow::onAddNote() {
    NoteDialog dialog(this);
    dialog.setWindowTitle(QStringLiteral("Новая заметка"));

    if (dialog.exec() == QDialog::Accepted) {
        Note note(dialog.title(), dialog.body(), dialog.label());
        m_manager->addNote(note);
    }
}

void MainWindow::onEditNote(const QString &noteId) {
    Note *note = m_manager->findNoteById(noteId);
    if (!note) return;

    NoteDialog dialog(this);
    dialog.setWindowTitle(QStringLiteral("Редактирование"));
    dialog.setTitle(note->title());
    dialog.setBody(note->body());
    dialog.setLabel(note->label());

    if (dialog.exec() == QDialog::Accepted) {
        m_manager->updateNote(noteId, dialog.title(), dialog.body(), dialog.label());
    }
}

void MainWindow::onDeleteNote(const QString &noteId) {
    m_manager->removeNote(noteId);
}

void MainWindow::onFilterChanged() {
    refreshNotesList();
}

QVector<Note> MainWindow::getFilteredNotes() const {
    // Сортировка
    int sortMode = m_sortCombo->currentData().toInt();
    switch (sortMode) {
    case 1:  m_manager->sortByDateAscending(); break;
    case 2:  m_manager->sortByTitle(); break;
    default: m_manager->sortByDateDescending(); break;
    }

    // Фильтр по лейблу
    int filterValue = m_filterCombo->currentData().toInt();
    QVector<Note> notes;
    if (filterValue < 0) {
        notes = m_manager->allNotes();
    } else {
        notes = m_manager->notesByLabel(static_cast<Label>(filterValue));
    }

    // Поиск
    QString query = m_searchEdit->text().trimmed();
    if (!query.isEmpty()) {
        QVector<Note> filtered;
        for (const auto &note : notes) {
            if (note.title().contains(query, Qt::CaseInsensitive) ||
                note.body().contains(query, Qt::CaseInsensitive)) {
                filtered.append(note);
            }
        }
        return filtered;
    }

    return notes;
}

void MainWindow::refreshNotesList() {
    // Удаляем старые карточки
    QLayoutItem *item;
    while ((item = m_notesLayout->takeAt(0)) != nullptr) {
        if (item->widget()) {
            delete item->widget();
        }
        delete item;
    }

    QVector<Note> notes = getFilteredNotes();

    if (notes.isEmpty()) {
        auto *emptyLabel = new QLabel(QStringLiteral("Заметок пока нет. Создайте первую! 📝"), this);
        emptyLabel->setAlignment(Qt::AlignCenter);
        emptyLabel->setStyleSheet("font-size: 16px; color: #9e9e9e; padding: 40px;");
        m_notesLayout->addWidget(emptyLabel);
    } else {
        for (const auto &note : notes) {
            auto *card = new NoteCard(note, this);
            connect(card, &NoteCard::editRequested, this, &MainWindow::onEditNote);
            connect(card, &NoteCard::deleteRequested, this, &MainWindow::onDeleteNote);
            m_notesLayout->addWidget(card);
        }
    }

    m_notesLayout->addStretch();
}
