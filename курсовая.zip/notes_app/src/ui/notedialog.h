#ifndef NOTEDIALOG_H
#define NOTEDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QTextEdit>
#include <QComboBox>
#include <QPushButton>

#include "models/label.h"

class NoteDialog : public QDialog {
    Q_OBJECT
public:
    explicit NoteDialog(QWidget *parent = nullptr);

    void setTitle(const QString &title);
    void setBody(const QString &body);
    void setLabel(Label label);

    QString title() const;
    QString body() const;
    Label label() const;

private:
    QLineEdit *m_titleEdit;
    QTextEdit *m_bodyEdit;
    QComboBox *m_labelCombo;
    QPushButton *m_saveButton;
    QPushButton *m_cancelButton;

    void setupUi();
    void populateLabels();
};

#endif // NOTEDIALOG_H
