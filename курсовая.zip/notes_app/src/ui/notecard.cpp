#include "ui/notecard.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>

NoteCard::NoteCard(const Note &note, QWidget *parent)
    : QFrame(parent)
    , m_noteId(note.id())
{
    setupUi();
    updateFromNote(note);
}

void NoteCard::setupUi() {
    setFrameStyle(QFrame::StyledPanel | QFrame::Raised);
    setLineWidth(1);
    setFixedHeight(160);
    setStyleSheet(
        "NoteCard {"
        "  background-color: #ffffff;"
        "  border: 1px solid #e0e0e0;"
        "  border-radius: 8px;"
        "  padding: 12px;"
        "}"
        "NoteCard:hover {"
        "  border-color: #b0b0b0;"
        "  background-color: #fafafa;"
        "}"
        );

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(6);

    // Верхняя строка: заголовок + лейбл
    auto *topLayout = new QHBoxLayout();
    m_titleLabel = new QLabel(this);
    m_titleLabel->setStyleSheet("font-size: 16px; font-weight: bold; color: #212121;");
    m_titleLabel->setWordWrap(false);

    m_labelBadge = new QLabel(this);
    m_labelBadge->setFixedHeight(24);
    m_labelBadge->setAlignment(Qt::AlignCenter);
    m_labelBadge->setStyleSheet(
        "border-radius: 12px; padding: 2px 10px; font-size: 11px; color: white;"
        );

    topLayout->addWidget(m_titleLabel, 1);
    topLayout->addWidget(m_labelBadge);

    // Тело заметки (превью)
    m_bodyPreview = new QLabel(this);
    m_bodyPreview->setStyleSheet("font-size: 13px; color: #616161;");
    m_bodyPreview->setWordWrap(true);
    m_bodyPreview->setMaximumHeight(50);

    // Нижняя строка: дата + кнопки
    auto *bottomLayout = new QHBoxLayout();
    m_dateLabel = new QLabel(this);
    m_dateLabel->setStyleSheet("font-size: 11px; color: #9e9e9e;");

    m_editButton = new QPushButton(QStringLiteral("✏ Изменить"), this);
    m_deleteButton = new QPushButton(QStringLiteral("🗑 Удалить"), this);

    m_editButton->setFixedSize(100, 28);
    m_deleteButton->setFixedSize(100, 28);

    m_editButton->setStyleSheet(
        "QPushButton { background-color: #4285f4; color: white; border: none;"
        "border-radius: 4px; font-size: 12px; }"
        "QPushButton:hover { background-color: #3367d6; }"
        );
    m_deleteButton->setStyleSheet(
        "QPushButton { background-color: #ea4335; color: white; border: none;"
        "border-radius: 4px; font-size: 12px; }"
        "QPushButton:hover { background-color: #c62828; }"
        );

    bottomLayout->addWidget(m_dateLabel, 1);
    bottomLayout->addWidget(m_editButton);
    bottomLayout->addWidget(m_deleteButton);

    mainLayout->addLayout(topLayout);
    mainLayout->addWidget(m_bodyPreview, 1);
    mainLayout->addLayout(bottomLayout);

    connect(m_editButton, &QPushButton::clicked, this, [this]() {
        emit editRequested(m_noteId);
    });

    connect(m_deleteButton, &QPushButton::clicked, this, [this]() {
        auto reply = QMessageBox::question(
            this,
            QStringLiteral("Удаление"),
            QStringLiteral("Удалить эту заметку?"),
            QMessageBox::Yes | QMessageBox::No
            );
        if (reply == QMessageBox::Yes) {
            emit deleteRequested(m_noteId);
        }
    });
}

void NoteCard::updateFromNote(const Note &note) {
    m_titleLabel->setText(note.title().isEmpty()
                          ? QStringLiteral("Без названия") : note.title());

    QString preview = note.body().left(120);
    if (note.body().length() > 120) {
        preview += QStringLiteral("...");
    }
    m_bodyPreview->setText(preview);

    m_dateLabel->setText(note.updatedAt().toString("dd.MM.yyyy hh:mm"));

    applyLabelStyle(note.label());
}

QString NoteCard::noteId() const {
    return m_noteId;
}

void NoteCard::applyLabelStyle(Label label) {
    m_labelBadge->setText(LabelUtils::toString(label));
    QColor color = LabelUtils::toColor(label);
    m_labelBadge->setStyleSheet(
        QString("background-color: %1; border-radius: 12px; "
                "padding: 2px 10px; font-size: 11px; color: white;")
            .arg(color.name())
        );
}
