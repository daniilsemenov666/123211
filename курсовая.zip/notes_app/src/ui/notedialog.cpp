#include "ui/notedialog.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>

NoteDialog::NoteDialog(QWidget *parent)
    : QDialog(parent)
{
    setupUi();
    populateLabels();
}

void NoteDialog::setupUi() {
    setWindowTitle(QStringLiteral("Заметка"));
    setMinimumSize(450, 400);

    auto *layout = new QVBoxLayout(this);
    layout->setSpacing(12);

    // Название
    auto *titleLbl = new QLabel(QStringLiteral("Название:"), this);
    titleLbl->setStyleSheet("font-weight: bold; font-size: 14px;");
    m_titleEdit = new QLineEdit(this);
    m_titleEdit->setPlaceholderText(QStringLiteral("Введите название заметки..."));
    m_titleEdit->setStyleSheet("padding: 8px; font-size: 14px; border: 1px solid #ccc; border-radius: 4px;");

    // Лейбл
    auto *labelLbl = new QLabel(QStringLiteral("Метка:"), this);
    labelLbl->setStyleSheet("font-weight: bold; font-size: 14px;");
    m_labelCombo = new QComboBox(this);
    m_labelCombo->setStyleSheet("padding: 6px; font-size: 13px;");

    // Текст заметки
    auto *bodyLbl = new QLabel(QStringLiteral("Текст заметки:"), this);
    bodyLbl->setStyleSheet("font-weight: bold; font-size: 14px;");
    m_bodyEdit = new QTextEdit(this);
    m_bodyEdit->setPlaceholderText(QStringLiteral("Введите текст заметки..."));
    m_bodyEdit->setStyleSheet("padding: 8px; font-size: 13px; border: 1px solid #ccc; border-radius: 4px;");

    // Кнопки
    auto *buttonLayout = new QHBoxLayout();
    m_saveButton = new QPushButton(QStringLiteral("💾 Сохранить"), this);
    m_cancelButton = new QPushButton(QStringLiteral("Отмена"), this);

    m_saveButton->setStyleSheet(
        "QPushButton { background-color: #34a853; color: white; border: none;"
        "border-radius: 6px; padding: 10px 24px; font-size: 14px; }"
        "QPushButton:hover { background-color: #2d8e47; }"
        );
    m_cancelButton->setStyleSheet(
        "QPushButton { background-color: #757575; color: white; border: none;"
        "border-radius: 6px; padding: 10px 24px; font-size: 14px; }"
        "QPushButton:hover { background-color: #616161; }"
        );

    buttonLayout->addStretch();
    buttonLayout->addWidget(m_cancelButton);
    buttonLayout->addWidget(m_saveButton);

    layout->addWidget(titleLbl);
    layout->addWidget(m_titleEdit);
    layout->addWidget(labelLbl);
    layout->addWidget(m_labelCombo);
    layout->addWidget(bodyLbl);
    layout->addWidget(m_bodyEdit, 1);
    layout->addLayout(buttonLayout);

    connect(m_saveButton, &QPushButton::clicked, this, [this]() {
        if (m_titleEdit->text().trimmed().isEmpty()) {
            QMessageBox::warning(this, QStringLiteral("Ошибка"),
                                 QStringLiteral("Название не может быть пустым"));
            return;
        }
        accept();
    });

    connect(m_cancelButton, &QPushButton::clicked, this, &QDialog::reject);
}

void NoteDialog::populateLabels() {
    for (Label label : LabelUtils::allLabels()) {
        m_labelCombo->addItem(LabelUtils::toString(label), static_cast<int>(label));
    }
}

void NoteDialog::setTitle(const QString &title) { m_titleEdit->setText(title); }
void NoteDialog::setBody(const QString &body) { m_bodyEdit->setText(body); }

void NoteDialog::setLabel(Label label) {
    int idx = m_labelCombo->findData(static_cast<int>(label));
    if (idx >= 0) {
        m_labelCombo->setCurrentIndex(idx);
    }
}

QString NoteDialog::title() const { return m_titleEdit->text().trimmed(); }
QString NoteDialog::body() const { return m_bodyEdit->toPlainText(); }

Label NoteDialog::label() const {
    return static_cast<Label>(m_labelCombo->currentData().toInt());
}
