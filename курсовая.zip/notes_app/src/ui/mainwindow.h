#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QScrollArea>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>

#include "services/notemanager.h"

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(NoteManager *manager, QWidget *parent = nullptr);

private slots:
    void onAddNote();
    void onEditNote(const QString &noteId);
    void onDeleteNote(const QString &noteId);
    void onFilterChanged();
    void refreshNotesList();

private:
    NoteManager *m_manager;

    QWidget *m_centralWidget;
    QVBoxLayout *m_notesLayout;
    QScrollArea *m_scrollArea;
    QComboBox *m_filterCombo;
    QComboBox *m_sortCombo;
    QLineEdit *m_searchEdit;
    QPushButton *m_addButton;

    void setupUi();
    void setupToolbar();
    QVector<Note> getFilteredNotes() const;
};

#endif // MAINWINDOW_H
