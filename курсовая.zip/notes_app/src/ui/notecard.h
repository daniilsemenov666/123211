#ifndef NOTECARD_H
#define NOTECARD_H

#include <QFrame>
#include <QLabel>
#include <QPushButton>

#include "models/note.h"

class NoteCard : public QFrame {
    Q_OBJECT
public:
    explicit NoteCard(const Note &note, QWidget *parent = nullptr);

    QString noteId() const;
    void updateFromNote(const Note &note);

signals:
    void editRequested(const QString &noteId);
    void deleteRequested(const QString &noteId);

private:
    QString m_noteId;
    QLabel *m_titleLabel;
    QLabel *m_bodyPreview;
    QLabel *m_labelBadge;
    QLabel *m_dateLabel;
    QPushButton *m_editButton;
    QPushButton *m_deleteButton;

    void setupUi();
    void applyLabelStyle(Label label);
};

#endif // NOTECARD_H
