#ifndef NOTEMANAGER_H
#define NOTEMANAGER_H

#include <QObject>
#include <QVector>

#include "models/note.h"
#include "services/storageservice.h"

class NoteManager : public QObject {
    Q_OBJECT
public:
    explicit NoteManager(StorageService *storage, QObject *parent = nullptr);

    QVector<Note> allNotes() const;
    QVector<Note> notesByLabel(Label label) const;
    QVector<Note> searchNotes(const QString &query) const;

    void addNote(const Note &note);
    bool updateNote(const QString &id, const QString &title,
                    const QString &body, Label label);
    bool removeNote(const QString &id);

    Note* findNoteById(const QString &id);
    int count() const;

    void sortByDateAscending();
    void sortByDateDescending();
    void sortByTitle();

    bool saveAll() const;
    void loadAll();

signals:
    void notesChanged();

private:
    QVector<Note> m_notes;
    StorageService *m_storage;

    int indexById(const QString &id) const;
};

#endif // NOTEMANAGER_H
