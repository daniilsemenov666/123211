#include "services/notemanager.h"

#include <algorithm>

NoteManager::NoteManager(StorageService *storage, QObject *parent)
    : QObject(parent)
    , m_storage(storage)
{
}

QVector<Note> NoteManager::allNotes() const {
    return m_notes;
}

QVector<Note> NoteManager::notesByLabel(Label label) const {
    QVector<Note> filtered;
    for (const auto &note : m_notes) {
        if (note.label() == label) {
            filtered.append(note);
        }
    }
    return filtered;
}

QVector<Note> NoteManager::searchNotes(const QString &query) const {
    if (query.isEmpty()) {
        return m_notes;
    }

    QVector<Note> results;
    for (const auto &note : m_notes) {
        if (note.title().contains(query, Qt::CaseInsensitive) ||
            note.body().contains(query, Qt::CaseInsensitive)) {
            results.append(note);
        }
    }
    return results;
}

void NoteManager::addNote(const Note &note) {
    m_notes.append(note);
    saveAll();
    emit notesChanged();
}

bool NoteManager::updateNote(const QString &id, const QString &title,
                             const QString &body, Label label) {
    int idx = indexById(id);
    if (idx < 0) {
        return false;
    }

    m_notes[idx].setTitle(title);
    m_notes[idx].setBody(body);
    m_notes[idx].setLabel(label);
    saveAll();
    emit notesChanged();
    return true;
}

bool NoteManager::removeNote(const QString &id) {
    int idx = indexById(id);
    if (idx < 0) {
        return false;
    }

    m_notes.removeAt(idx);
    saveAll();
    emit notesChanged();
    return true;
}

Note* NoteManager::findNoteById(const QString &id) {
    int idx = indexById(id);
    if (idx < 0) {
        return nullptr;
    }
    return &m_notes[idx];
}

int NoteManager::count() const {
    return m_notes.size();
}

void NoteManager::sortByDateAscending() {
    std::sort(m_notes.begin(), m_notes.end(),
              [](const Note &a, const Note &b) {
                  return a.updatedAt() < b.updatedAt();
              });
    emit notesChanged();
}

void NoteManager::sortByDateDescending() {
    std::sort(m_notes.begin(), m_notes.end(),
              [](const Note &a, const Note &b) {
                  return a.updatedAt() > b.updatedAt();
              });
    emit notesChanged();
}

void NoteManager::sortByTitle() {
    std::sort(m_notes.begin(), m_notes.end(),
              [](const Note &a, const Note &b) {
                  return a.title().toLower() < b.title().toLower();
              });
    emit notesChanged();
}

bool NoteManager::saveAll() const {
    return m_storage->save(m_notes);
}

void NoteManager::loadAll() {
    m_notes = m_storage->load();
    emit notesChanged();
}

int NoteManager::indexById(const QString &id) const {
    for (int i = 0; i < m_notes.size(); ++i) {
        if (m_notes[i].id() == id) {
            return i;
        }
    }
    return -1;
}
