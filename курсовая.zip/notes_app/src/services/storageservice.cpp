#include "services/storageservice.h"

#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QStandardPaths>
#include <QDir>
#include <QFileInfo>

StorageService::StorageService(const QString &filePath)
    : m_filePath(filePath.isEmpty() ? defaultFilePath() : filePath)
{
}

QString StorageService::defaultFilePath() {
    QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(dataDir);
    return dataDir + QStringLiteral("/notes.json");
}

QString StorageService::filePath() const {
    return m_filePath;
}

bool StorageService::save(const QVector<Note> &notes) const {
    QJsonArray array;
    for (const auto &note : notes) {
        array.append(note.toJson());
    }

    QJsonDocument doc(array);

    // Создаём директорию если не существует
    QFileInfo fileInfo(m_filePath);
    QDir().mkpath(fileInfo.absolutePath());

    QFile file(m_filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        return false;
    }

    file.write(doc.toJson(QJsonDocument::Indented));
    file.close();
    return true;
}

QVector<Note> StorageService::load() const {
    QVector<Note> notes;

    QFile file(m_filePath);
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) {
        return notes;
    }

    QByteArray data = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isArray()) {
        return notes;
    }

    QJsonArray array = doc.array();
    for (const auto &value : array) {
        if (value.isObject()) {
            notes.append(Note::fromJson(value.toObject()));
        }
    }

    return notes;
}
