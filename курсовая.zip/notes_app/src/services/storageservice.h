#ifndef STORAGESERVICE_H
#define STORAGESERVICE_H

#include <QString>
#include <QVector>

#include "models/note.h"

class StorageService {
public:
    explicit StorageService(const QString &filePath = QString());

    bool save(const QVector<Note> &notes) const;
    QVector<Note> load() const;
    QString filePath() const;

private:
    QString m_filePath;

    static QString defaultFilePath();
};

#endif // STORAGESERVICE_H
