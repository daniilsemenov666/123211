#include <QtTest/QtTest>
#include <QTemporaryFile>

#include "services/notemanager.h"
#include "services/storageservice.h"

class TestNoteManager : public QObject {
    Q_OBJECT

private:
    QString m_tempPath;
    StorageService *m_storage;
    NoteManager *m_manager;

private slots:
    void init() {
        m_tempPath = QDir::temp().filePath("test_notes_manager.json");
        m_storage = new StorageService(m_tempPath);
        m_manager = new NoteManager(m_storage);
    }

    void cleanup() {
        delete m_manager;
        delete m_storage;
        QFile::remove(m_tempPath);
    }

    void testAddNote() {
        QCOMPARE(m_manager->count(), 0);

        Note note("Тест", "Тело", Label::Work);
        m_manager->addNote(note);

        QCOMPARE(m_manager->count(), 1);
        QCOMPARE(m_manager->allNotes().first().title(), QString("Тест"));
    }

    void testRemoveNote() {
        Note note("Удалить", "Тело");
        m_manager->addNote(note);
        QCOMPARE(m_manager->count(), 1);

        bool result = m_manager->removeNote(note.id());
        QVERIFY(result);
        QCOMPARE(m_manager->count(), 0);
    }

    void testRemoveNonExistent() {
        bool result = m_manager->removeNote("nonexistent-id");
        QVERIFY(!result);
    }

    void testUpdateNote() {
        Note note("Старое", "Старое тело", Label::None);
        m_manager->addNote(note);

        bool result = m_manager->updateNote(note.id(), "Новое", "Новое тело", Label::Study);
        QVERIFY(result);

        Note *updated = m_manager->findNoteById(note.id());
        QVERIFY(updated != nullptr);
        QCOMPARE(updated->title(), QString("Новое"));
        QCOMPARE(updated->body(), QString("Новое тело"));
        QCOMPARE(updated->label(), Label::Study);
    }

    void testUpdateNonExistent() {
        bool result = m_manager->updateNote("fake-id", "A", "B", Label::None);
        QVERIFY(!result);
    }

    void testFindById() {
        Note note("Найти", "Тело");
        m_manager->addNote(note);

        Note *found = m_manager->findNoteById(note.id());
        QVERIFY(found != nullptr);
        QCOMPARE(found->title(), QString("Найти"));

        Note *notFound = m_manager->findNoteById("wrong-id");
        QVERIFY(notFound == nullptr);
    }

    void testFilterByLabel() {
        m_manager->addNote(Note("Работа 1", "", Label::Work));
        m_manager->addNote(Note("Учёба 1", "", Label::Study));
        m_manager->addNote(Note("Работа 2", "", Label::Work));
        m_manager->addNote(Note("Личное 1", "", Label::Personal));

        QVector<Note> workNotes = m_manager->notesByLabel(Label::Work);
        QCOMPARE(workNotes.size(), 2);

        QVector<Note> studyNotes = m_manager->notesByLabel(Label::Study);
        QCOMPARE(studyNotes.size(), 1);

        QVector<Note> urgentNotes = m_manager->notesByLabel(Label::Urgent);
        QCOMPARE(urgentNotes.size(), 0);
    }

    void testSearch() {
        m_manager->addNote(Note("Купить молоко", "В магазине"));
        m_manager->addNote(Note("Сделать ДЗ", "По математике"));
        m_manager->addNote(Note("Позвонить", "Маме"));

        QVector<Note> results = m_manager->searchNotes("молоко");
        QCOMPARE(results.size(), 1);
        QCOMPARE(results.first().title(), QString("Купить молоко"));

        results = m_manager->searchNotes("мат");
        QCOMPARE(results.size(), 1);

        results = m_manager->searchNotes("");
        QCOMPARE(results.size(), 3);

        results = m_manager->searchNotes("несуществующее");
        QCOMPARE(results.size(), 0);
    }

    void testSortByTitle() {
        m_manager->addNote(Note("Бета", ""));
        m_manager->addNote(Note("Альфа", ""));
        m_manager->addNote(Note("Гамма", ""));

        m_manager->sortByTitle();
        QVector<Note> notes = m_manager->allNotes();

        QCOMPARE(notes[0].title(), QString("Альфа"));
        QCOMPARE(notes[1].title(), QString("Бета"));
        QCOMPARE(notes[2].title(), QString("Гамма"));
    }

    void testSortByDate() {
        Note n1("Первая", "");
        m_manager->addNote(n1);
        QTest::qWait(15);

        Note n2("Вторая", "");
        m_manager->addNote(n2);
        QTest::qWait(15);

        Note n3("Третья", "");
        m_manager->addNote(n3);

        m_manager->sortByDateAscending();
        QVector<Note> asc = m_manager->allNotes();
        QCOMPARE(asc.first().title(), QString("Первая"));
        QCOMPARE(asc.last().title(), QString("Третья"));

        m_manager->sortByDateDescending();
        QVector<Note> desc = m_manager->allNotes();
        QCOMPARE(desc.first().title(), QString("Третья"));
        QCOMPARE(desc.last().title(), QString("Первая"));
    }

    void testPersistence() {
        m_manager->addNote(Note("Сохранённая", "Данные", Label::Ideas));
        m_manager->addNote(Note("Вторая", "Ещё данные", Label::Work));

        // Создаём новый менеджер с тем же хранилищем
        NoteManager newManager(m_storage);
        newManager.loadAll();

        QCOMPARE(newManager.count(), 2);
        QCOMPARE(newManager.allNotes()[0].title(), QString("Сохранённая"));
        QCOMPARE(newManager.allNotes()[0].label(), Label::Ideas);
    }

    void testSignalEmitted() {
        QSignalSpy spy(m_manager, &NoteManager::notesChanged);

        m_manager->addNote(Note("Тест", ""));
        QCOMPARE(spy.count(), 1);

        m_manager->removeNote(m_manager->allNotes().first().id());
        QCOMPARE(spy.count(), 2);
    }
};

QTEST_MAIN(TestNoteManager)
#include "test_notemanager.moc"
