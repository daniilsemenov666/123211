#include <QtTest/QtTest>
#include <QTemporaryDir>

#include "services/storageservice.h"

class TestStorageService : public QObject {
    Q_OBJECT

private:
    QTemporaryDir m_tempDir;

private slots:
    void testSaveAndLoad() {
        QString path = m_tempDir.filePath("test_save.json");
        StorageService storage(path);

        QVector<Note> notes;
        notes.append(Note("Заметка 1", "Тело 1", Label::Work));
        notes.append(Note("Заметка 2", "Тело 2", Label::Study));

        QVERIFY(storage.save(notes));

        QVector<Note> loaded = storage.load();
        QCOMPARE(loaded.size(), 2);
        QCOMPARE(loaded[0].title(), QString("Заметка 1"));
        QCOMPARE(loaded[0].label(), Label::Work);
        QCOMPARE(loaded[1].title(), QString("Заметка 2"));
        QCOMPARE(loaded[1].label(), Label::Study);
    }

    void testLoadNonExistentFile() {
        StorageService storage(m_tempDir.filePath("nonexistent.json"));
        QVector<Note> loaded = storage.load();
        QVERIFY(loaded.isEmpty());
    }

    void testSaveEmptyList() {
        QString path = m_tempDir.filePath("empty.json");
        StorageService storage(path);

        QVERIFY(storage.save(QVector<Note>()));

        QVector<Note> loaded = storage.load();
        QVERIFY(loaded.isEmpty());
    }

    void testOverwrite() {
        QString path = m_tempDir.filePath("overwrite.json");
        StorageService storage(path);

        QVector<Note> first;
        first.append(Note("Первая", ""));
        storage.save(first);

        QVector<Note> second;
        second.append(Note("Вторая", ""));
        second.append(Note("Третья", ""));
        storage.save(second);

        QVector<Note> loaded = storage.load();
        QCOMPARE(loaded.size(), 2);
        QCOMPARE(loaded[0].title(), QString("Вторая"));
    }

    void testFilePath() {
        QString path = "/tmp/test_path.json";
        StorageService storage(path);
        QCOMPARE(storage.filePath(), path);
    }

    void testDataIntegrity() {
        QString path = m_tempDir.filePath("integrity.json");
        StorageService storage(path);

        Note original("Тест целостности", "Длинный текст с символами: !@#$%^&*()", Label::Personal);
        QVector<Note> notes;
        notes.append(original);
        storage.save(notes);

        QVector<Note> loaded = storage.load();
        QCOMPARE(loaded.size(), 1);
        QCOMPARE(loaded[0].id(), original.id());
        QCOMPARE(loaded[0].title(), original.title());
        QCOMPARE(loaded[0].body(), original.body());
        QCOMPARE(loaded[0].label(), original.label());
    }

    void testCorruptedFile() {
        QString path = m_tempDir.filePath("corrupted.json");

        QFile file(path);
        file.open(QIODevice::WriteOnly);
        file.write("это не JSON");
        file.close();

        StorageService storage(path);
        QVector<Note> loaded = storage.load();
        QVERIFY(loaded.isEmpty());
    }
};

QTEST_MAIN(TestStorageService)
#include "test_storageservice.moc"
