#include <QtTest/QtTest>
#include "models/note.h"
#include "models/label.h"

class TestNote : public QObject {
    Q_OBJECT

private slots:
    void testDefaultConstructor() {
        Note note;
        QVERIFY(!note.id().isEmpty());
        QVERIFY(note.title().isEmpty());
        QVERIFY(note.body().isEmpty());
        QCOMPARE(note.label(), Label::None);
        QVERIFY(note.createdAt().isValid());
        QVERIFY(note.updatedAt().isValid());
    }

    void testParameterizedConstructor() {
        Note note("Тест", "Тело заметки", Label::Work);
        QCOMPARE(note.title(), QString("Тест"));
        QCOMPARE(note.body(), QString("Тело заметки"));
        QCOMPARE(note.label(), Label::Work);
    }

    void testSetters() {
        Note note;
        QDateTime beforeUpdate = note.updatedAt();

        QTest::qWait(10); // чтобы время отличалось

        note.setTitle("Новое название");
        QCOMPARE(note.title(), QString("Новое название"));
        QVERIFY(note.updatedAt() >= beforeUpdate);

        note.setBody("Новое тело");
        QCOMPARE(note.body(), QString("Новое тело"));

        note.setLabel(Label::Study);
        QCOMPARE(note.label(), Label::Study);
    }

    void testJsonSerialization() {
        Note original("Заметка", "Содержимое", Label::Personal);
        QJsonObject json = original.toJson();

        Note restored = Note::fromJson(json);
        QCOMPARE(restored.id(), original.id());
        QCOMPARE(restored.title(), original.title());
        QCOMPARE(restored.body(), original.body());
        QCOMPARE(restored.label(), original.label());
    }

    void testEquality() {
        Note note1("A", "B", Label::Work);
        Note note2("C", "D", Label::Study);

        QVERIFY(note1 == note1);
        QVERIFY(note1 != note2);
    }

    void testUniqueIds() {
        Note note1;
        Note note2;
        QVERIFY(note1.id() != note2.id());
    }

    // --- Тесты LabelUtils ---

    void testLabelToString() {
        QCOMPARE(LabelUtils::toString(Label::Work), QString("Работа"));
        QCOMPARE(LabelUtils::toString(Label::Personal), QString("Личное"));
        QCOMPARE(LabelUtils::toString(Label::Study), QString("Учёба"));
        QCOMPARE(LabelUtils::toString(Label::Urgent), QString("Срочное"));
        QCOMPARE(LabelUtils::toString(Label::Ideas), QString("Идеи"));
        QCOMPARE(LabelUtils::toString(Label::None), QString("Без метки"));
    }

    void testLabelFromString() {
        QCOMPARE(LabelUtils::fromString("Работа"), Label::Work);
        QCOMPARE(LabelUtils::fromString("Личное"), Label::Personal);
        QCOMPARE(LabelUtils::fromString("Учёба"), Label::Study);
        QCOMPARE(LabelUtils::fromString("неизвестно"), Label::None);
    }

    void testLabelRoundTrip() {
        for (Label label : LabelUtils::allLabels()) {
            QString str = LabelUtils::toString(label);
            Label restored = LabelUtils::fromString(str);
            QCOMPARE(restored, label);
        }
    }

    void testAllLabelsCount() {
        QVector<Label> all = LabelUtils::allLabels();
        QCOMPARE(all.size(), 6);
    }

    void testLabelColors() {
        for (Label label : LabelUtils::allLabels()) {
            QColor color = LabelUtils::toColor(label);
            QVERIFY(color.isValid());
        }
    }
};

QTEST_MAIN(TestNote)
#include "test_note.moc"
